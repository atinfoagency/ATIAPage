import React, { useEffect, useState, useRef } from "react";
import { 
  ArrowRight, 
  CheckCircle2, 
  BarChart3, 
  Users, 
  Lock, 
  Zap, 
  TrendingUp, 
  ShieldCheck, 
  ChevronDown,
  X,
  XCircle,
  FileText,
  CircleDollarSign,
  Play,
  Loader2
} from "lucide-react";
import { motion, AnimatePresence, useScroll, useTransform, animate, useMotionValue } from "framer-motion";

// --- Types ---

interface RevealProps {
  children: React.ReactNode;
  delay?: number;
}

// --- Components ---

// Reusable Reveal Animation Component
const Reveal: React.FC<RevealProps> = ({ children, delay = 0 }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.6, delay, ease: "easeOut" }}
    >
      {children}
    </motion.div>
  );
};

const AntigravityLogo = ({ className = "text-white" }: { className?: string }) => (
  <span className="font-bold whitespace-nowrap">
    <span className="bg-clip-text text-transparent bg-gradient-to-r from-[#6B21A8] to-[#A78BFA]">ANTI</span>
    <span className={className}>GRAVITY ENGINE™</span>
  </span>
);

// Navbar
const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <motion.nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "py-4 bg-background/80 backdrop-blur-md border-b border-white/5" : "py-6 bg-transparent"
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
        <div className="text-xl font-bold tracking-tighter text-white">
          ATIA<span className="text-purple-500">.</span>
        </div>
        <a 
          href="https://cal.com/at-info/20min"
          target="_blank"
          rel="noreferrer"
          className="flex items-center gap-2 px-3 py-1.5 sm:px-5 sm:py-2 rounded-full bg-white text-black font-medium text-xs sm:text-sm hover:scale-105 transition-transform duration-200"
        >
          Get Your Custom Blueprint
        </a>
      </div>
    </motion.nav>
  );
};

const AnimatedFollowers = () => {
  const count = useMotionValue(0);
  const rounded = useTransform(count, (latest) => Math.round(latest));
  const [displayValue, setDisplayValue] = useState("0");

  useEffect(() => {
    const controls = animate(count, 10000, { duration: 2, ease: "easeOut" });
    
    const unsubscribe = rounded.on("change", (latest) => {
      setDisplayValue(latest.toLocaleString());
    });

    return () => {
      controls.stop();
      unsubscribe();
    };
  }, [count, rounded]);

  return <span>{displayValue}+</span>;
};

// Hero Section
const HeroSection = () => {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"]
  });
  
  // Fade out starts when the section is 60% scrolled up, fully transparent at 90%
  const opacity = useTransform(scrollYProgress, [0.6, 0.9], [1, 0]);
  const y1 = useTransform(scrollYProgress, [0, 1], [0, 200]);

  const [videoState, setVideoState] = useState<'idle' | 'loading' | 'error'>('idle');

  const handleVideoClick = () => {
    if (videoState !== 'idle') return;
    setVideoState('loading');
    setTimeout(() => {
      setVideoState('error');
    }, 2000);
  };

  const handleScrollToSystem = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const element = document.getElementById('system');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <section ref={ref} className="relative min-h-screen flex items-center justify-center overflow-hidden pt-32 pb-20">
      {/* Background Ambience */}
      <div className="absolute inset-0 w-full h-full bg-background pointer-events-none">
          <div className="absolute top-[-10%] left-[-10%] w-96 h-96 bg-purple-500/20 rounded-full mix-blend-screen filter blur-[100px] animate-blob" />
          <div className="absolute top-[-10%] right-[-10%] w-96 h-96 bg-blue-500/20 rounded-full mix-blend-screen filter blur-[100px] animate-blob animation-delay-2000" />
          <div className="absolute bottom-[-20%] left-[20%] w-96 h-96 bg-indigo-500/10 rounded-full mix-blend-screen filter blur-[100px] animate-blob animation-delay-4000" />
        </div>

        <div className="container mx-auto px-6 relative z-10 text-center">
          <motion.div style={{ y: y1, opacity }}>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass-panel text-xs font-medium text-blue-200 mb-8"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
            </span>
            Built on Systems You Own • Zero Platform Dependency • Revenue You Control
          </motion.div>

          <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold tracking-tight text-balance mb-4 bg-clip-text text-transparent bg-gradient-to-b from-white via-white to-gray-400">
            IF YOU HAVE <AnimatedFollowers /> FOLLOWERS AND YOU&apos;RE NOT MAKING $20K/MONTH FROM THEM
          </h1>

          {/* VSL Placeholder */}
          <div className="w-full max-w-4xl mx-auto mb-10 relative aspect-video rounded-2xl overflow-hidden border border-white/10 bg-white/5 cursor-pointer group" onClick={handleVideoClick}>
            <div className="absolute inset-0 bg-gradient-to-tr from-purple-500/10 to-blue-500/10 mix-blend-overlay" />
            
            {videoState === 'idle' && (
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center backdrop-blur-md border border-white/20 group-hover:scale-110 transition-transform">
                  <Play className="w-6 h-6 text-white ml-1" fill="currentColor" />
                </div>
                <p className="mt-4 text-sm text-secondary font-mono">Click to watch the breakdown</p>
              </div>
            )}

            {videoState === 'loading' && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-background/80 backdrop-blur-sm">
                <Loader2 className="w-10 h-10 text-purple-500 animate-spin" />
                <p className="mt-4 text-sm text-white font-mono animate-pulse">Loading video...</p>
              </div>
            )}

            {videoState === 'error' && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-background/90 backdrop-blur-md">
                <XCircle className="w-12 h-12 text-red-500 mb-4" />
                <p className="text-lg text-white font-medium">Ops, there must have been a mistake.</p>
                <p className="text-sm text-secondary mt-2">Refresh the page.</p>
              </div>
            )}
          </div>

          <div className="w-full max-w-4xl mx-auto mb-10 p-6 md:p-8 rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm text-left shadow-xl space-y-6">
            <p className="text-lg md:text-xl text-white/90 leading-relaxed text-balance">
              You&apos;re doing what every &quot;guru&quot; told you to do:
            </p>
            <p className="text-lg md:text-xl text-white/90 leading-relaxed text-balance font-medium">
              Build an audience → Create a course → Launch it → Pray it sells.
            </p>
            <p className="text-lg md:text-xl text-white/90 leading-relaxed text-balance">
              And it worked... sort of.
            </p>
            <p className="text-lg md:text-xl text-white/90 leading-relaxed text-balance">
              You made some sales. Maybe $2K-$5K on a good launch.<br/>
              Then crickets until the next one.
            </p>
            <p className="text-lg md:text-xl text-white/90 leading-relaxed text-balance">
              Meanwhile, creators with SMALLER audiences than yours are quietly collecting $3,000–$5,000 per client, every month, on autopilot.
            </p>
            <p className="text-lg md:text-xl text-white/90 leading-relaxed text-balance">
              The difference isn&apos;t their content. It&apos;s their system.
            </p>
            <p className="text-lg md:text-xl text-white/90 leading-relaxed text-balance">
              They replaced the &quot;launch and pray&quot; model with a High-Ticket Conversion Engine—a system that turns followers into $3K-$5K clients without launches, webinars, or posting more content.
            </p>
            <p className="text-lg md:text-xl text-white/90 leading-relaxed text-balance">
              Want to see what that system looks like for YOUR business? Let Us Introduce to you <AntigravityLogo />. In 15-20 minutes, we&apos;ll map out your custom monetization blueprint—whether you work with us or not.
            </p>
            
            <div className="pt-4 flex flex-col items-center justify-center gap-4">
              <a
                href="https://cal.com/at-info/20min"
                target="_blank"
                rel="noreferrer"
                className="group relative px-6 py-4 md:px-8 md:py-4 bg-white text-black font-semibold rounded-full hover:bg-gray-100 transition-all flex flex-col items-center gap-1 text-center w-full max-w-md"
              >
                <span className="flex items-center gap-2 text-sm md:text-base">
                  Get Your Personalized Antigravity Blueprint
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform shrink-0" />
                </span>
                <span className="text-[10px] md:text-xs font-normal opacity-70">
                  Free 20-Min Revenue Audit (No Pitch, Just Your Custom Growth Map)
                </span>
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

// Fit Section
const FitSection = () => {
  const forYou = [
    "Your content consistently gets views or engagement",
    'People DM you, ask questions, or "love your content"',
    "You know there's business potential — but nothing is structured"
  ];

  const notForYou = [
    "You're still trying to grow your first audience",
    "You want hacks, scripts, or shortcuts",
    "You're looking for motivation instead of systems"
  ];

  return (
    <section className="py-20 bg-background relative overflow-hidden" id="fit">
      {/* ambient */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-[520px] h-[520px] bg-blue-500/10 rounded-full blur-[110px]" />
        <div className="absolute -bottom-32 -left-20 w-[520px] h-[520px] bg-purple-500/10 rounded-full blur-[120px]" />
        <div className="absolute inset-0 bg-grid-white/[0.03]" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <Reveal>
          <div className="text-center max-w-3xl mx-auto mb-10">
            <div className="text-xs font-mono tracking-widest text-secondary uppercase mb-3">
              WHO THIS IS FOR
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-3">
              (Read This Before You Apply)
            </h2>
            <p className="text-secondary leading-relaxed mb-4">
              <AntigravityLogo /> is not for everyone.<br/>
              If people already DM you asking how to work with you and you don&apos;t have a clear answer — you need the Engine. If nobody is asking yet — you need more content first.
            </p>
            <p className="text-secondary">
              Here&apos;s how to know if you&apos;re one of them.
            </p>
          </div>
        </Reveal>

        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* FOR YOU */}
          <Reveal delay={0.05}>
            <motion.div 
              whileHover={{ scale: 1.02 }}
              className="glass-panel rounded-3xl p-8 border border-white/10 bg-white/5 transition-all duration-300 hover:bg-white/10 hover:border-white/20 hover:shadow-2xl"
            >
              <div className="flex items-start justify-between gap-4 mb-6">
                <div>
                  <div className="text-xs font-mono tracking-wider text-blue-200 uppercase mb-2">
                    This is for you if
                  </div>
                  <h3 className="text-2xl font-semibold text-white">
                    You have signal… but no structure
                  </h3>
                </div>

                <div className="w-10 h-10 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-blue-300">
                  <CheckCircle2 size={20} />
                </div>
              </div>

              <ul className="space-y-3">
                {forYou.map((t, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <span className="mt-2 w-2 h-2 rounded-full bg-blue-400 shrink-0" />
                    <span className="text-white/85 leading-relaxed">{t}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-7 pt-6 border-t border-white/10 text-sm text-secondary">
                If this is you, the diagnostic will feel like a relief.
              </div>
            </motion.div>
          </Reveal>

          {/* NOT FOR YOU */}
          <Reveal delay={0.1}>
            <motion.div 
              whileHover={{ scale: 1.02 }}
              className="glass-panel rounded-3xl p-8 border border-white/10 bg-white/5 transition-all duration-300 hover:bg-white/10 hover:border-white/20 hover:shadow-2xl"
            >
              <div className="flex items-start justify-between gap-4 mb-6">
                <div>
                  <div className="text-xs font-mono tracking-wider text-purple-200 uppercase mb-2">
                    This is not for you if
                  </div>
                  <h3 className="text-2xl font-semibold text-white">
                    You want shortcuts over systems
                  </h3>
                </div>

                <div className="w-10 h-10 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-purple-300">
                  <XCircle size={20} />
                </div>
              </div>

              <ul className="space-y-3">
                {notForYou.map((t, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <span className="mt-2 w-2 h-2 rounded-full bg-purple-400 shrink-0" />
                    <span className="text-white/85 leading-relaxed">{t}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-7 pt-6 border-t border-white/10 text-sm text-secondary">
                No judgment — it’s just not the lane here.
              </div>
            </motion.div>
          </Reveal>
        </div>

        {/* subtle CTA row */}
        <Reveal delay={0.15}>
          <motion.div 
            whileHover={{ scale: 1.01 }}
            className="max-w-4xl mx-auto mt-10 flex flex-col md:flex-row items-center justify-between gap-4 glass-panel rounded-3xl p-6 border border-white/10 bg-white/5 transition-all duration-300 hover:bg-white/10 hover:border-white/20 hover:shadow-xl"
          >
            <div className="text-sm text-white/85">
              All in 20 minutes. Free. No pitch.
            </div>
            <a
              href="https://cal.com/at-info/20min"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full bg-white text-black font-semibold hover:bg-gray-100 transition-all"
            >
              Get Your Free Custom Blueprint
              <ArrowRight className="w-4 h-4" />
            </a>
          </motion.div>
        </Reveal>
      </div>
    </section>
  );
};

// Social Proof Section
const SocialProofSection = () => {
  return (
    <section className="py-24 bg-background relative overflow-hidden" id="proof">
      <div className="container mx-auto px-6 relative z-10">
        <Reveal>
          <div className="text-center max-w-5xl mx-auto mb-12">
            <div className="flex flex-col items-center gap-6 mb-12">
              <h2 className="text-4xl md:text-6xl font-bold tracking-tight">
                HERE&apos;S THE TRUTH ABOUT ATIA.
              </h2>
              <h3 className="text-2xl md:text-3xl font-semibold text-secondary">
                WE DIDN&apos;T START WITH CLIENTS.<br/>
                WE STARTED WITH A QUESTION.
              </h3>
              <p className="text-xl md:text-2xl text-purple-400 font-medium italic max-w-3xl">
                &quot;Why are creators with massive audiences still broke?&quot;
              </p>
              <p className="text-lg text-secondary max-w-2xl">
                We studied the problem. We analyzed hundreds of creator businesses. We mapped the patterns.
              </p>
              <h3 className="text-2xl md:text-3xl font-bold text-white mt-4">
                So, WE BUILT SOMETHING NOBODY ELSE HAS.
              </h3>
              <p className="text-lg text-white/90 max-w-3xl text-balance">
                <AntigravityLogo /> — a funnel architecture that starts with your Content and Builds you a Premium offer and ends with revenue &quot;Without You Doing Extra Work&quot;
              </p>
            </div>
            
            <div className="relative rounded-2xl overflow-hidden mb-12 flex justify-center">
              <img 
                src="/screenshot.png" 
                alt="Market Demand Social Proof" 
                className="w-full max-w-4xl h-auto object-contain rounded-xl"
              />
            </div>

            <div className="glass-panel rounded-2xl p-8 border border-white/10 bg-white/5 text-center max-w-3xl mx-auto">
              <h3 className="text-2xl font-black mb-6 font-serif"><span className="text-purple-400">WHY SHOULD YOU TRUST US?</span></h3>
              <div className="space-y-4 text-secondary leading-relaxed text-lg">
                <p>Honestly? You shouldn&apos;t. Not yet.</p>
                <p>That&apos;s why we offer a free System Audit.</p>
                <p>No payment. No commitment. Just a 15-20 minute call where we show you exactly what your <AntigravityLogo /> would look like — custom-built for your audience, your niche, and your expertise.</p>
                <p>If you walk away thinking &quot;this is legit&quot; — great. We&apos;ll talk about working together.</p>
                <p>If you walk away thinking &quot;not for me&quot; — also great. You&apos;ll still have a blueprint you can implement yourself.</p>
                <p className="font-medium text-white/90">We&apos;re confident enough in what we built to let you judge it for free.</p>
                <div className="pt-6 flex justify-center">
                  <a
                    href="#system"
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full bg-white/10 border border-white/20 text-white font-semibold hover:bg-white/20 transition-all"
                  >
                    See the <AntigravityLogo />
                    <ArrowRight className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

// Real Problem Section
const RealProblemSection = () => {
  return (
    <section className="py-24 bg-background relative overflow-hidden" id="problem">
      {/* ambience */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -top-28 -right-20 w-[560px] h-[560px] bg-indigo-500/10 rounded-full blur-[120px]" />
        <div className="absolute -bottom-32 -left-24 w-[560px] h-[560px] bg-blue-500/10 rounded-full blur-[120px]" />
        <div className="absolute inset-0 bg-grid-white/[0.03]" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <Reveal>
          <div className="text-center max-w-4xl mx-auto mb-14">
            <h2 className="text-3xl md:text-5xl font-bold mb-8">
              THE HIDDEN GAP NOBODY TALKS ABOUT.
            </h2>
            <hr className="border-white/10 mb-8" />
            <p className="text-xl text-white/90 leading-relaxed mb-6">
              Every creator we&apos;ve studied has the same three assets:
            </p>
            <ul className="text-lg text-secondary space-y-2 mb-8 inline-block text-left">
              <li>✅ <span className="text-white">Attention</span> — People watch your content</li>
              <li>✅ <span className="text-white">Trust</span> — People believe what you say</li>
              <li>✅ <span className="text-white">Demand</span> — People want to learn from you</li>
            </ul>
            <p className="text-xl text-white/90 leading-relaxed mb-6">
              And the same one gap:
            </p>
            <p className="text-2xl font-bold text-red-400 mb-4">
              ❌ No structured supply
            </p>
            <p className="text-lg text-secondary mb-12">
              No clear offer. No conversion path.<br/>
              No system to turn &quot;I love your content&quot;<br/>
              into &quot;Here&apos;s $3,000 for your help.&quot;
            </p>
          </div>
        </Reveal>

        {/* 3 columns */}
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 relative">
          {/* Arrow connectors for desktop */}
          <div className="hidden md:block absolute top-1/2 left-1/3 -translate-x-1/2 -translate-y-1/2 z-0 text-white/20">
            <ArrowRight size={48} />
          </div>
          <div className="hidden md:block absolute top-1/2 right-1/3 translate-x-1/2 -translate-y-1/2 z-0 text-white/20">
            <ArrowRight size={48} className="border-dashed" />
          </div>

          <Reveal delay={0.05}>
            <motion.div
              whileHover={{ y: -8, scale: 1.02 }}
              className="glass-panel rounded-3xl p-8 border border-white/10 bg-white/5 h-full relative z-10"
            >
              <div className="text-xs font-mono tracking-wider text-green-400 uppercase mb-3">
                COLUMN 1: ATTENTION ✅
              </div>
              <p className="text-secondary leading-relaxed">
                Your content gets views.<br/>
                People engage, share, comment.<br/>
                DMs come in daily.<br/>
                You have DEMAND.
              </p>
            </motion.div>
          </Reveal>

          <Reveal delay={0.15}>
            <motion.div
              whileHover={{ y: -8, scale: 1.02 }}
              className="glass-panel rounded-3xl p-8 border border-red-500/30 bg-red-500/5 h-full relative z-10"
            >
              <div className="text-xs font-mono tracking-wider text-red-400 uppercase mb-3">
                COLUMN 2: THE GAP ❌
              </div>
              <p className="text-secondary leading-relaxed">
                No clear offer to buy.<br/>
                No system to capture interest.<br/>
                No path from &quot;I love your content&quot;<br/>
                to &quot;Here&apos;s my credit card.&quot;
              </p>
            </motion.div>
          </Reveal>

          <Reveal delay={0.25}>
            <motion.div
              whileHover={{ y: -8, scale: 1.02 }}
              className="glass-panel rounded-3xl p-8 border border-white/10 bg-white/5 h-full relative z-10"
            >
              <div className="text-xs font-mono tracking-wider text-yellow-400 uppercase mb-3">
                COLUMN 3: REVENUE ❓
              </div>
              <p className="text-secondary leading-relaxed">
                $2K one month. $800 the next.<br/>
                Maybe $4K if you launch something.<br/>
                Random. Unpredictable.<br/>
                Exhausting.
              </p>
            </motion.div>
          </Reveal>
        </div>

        {/* closing punchline */}
        <Reveal delay={0.35}>
          <div className="max-w-4xl mx-auto mt-16 text-center">
            <p className="text-xl md:text-2xl font-semibold text-white leading-snug mb-8">
              The gap between Column 1 and Column 3 is where<br/>
              your money is leaking.
            </p>
            <p className="text-lg text-secondary mb-6">
              The fix isn&apos;t more content. It&apos;s <span className="text-white font-bold">STRUCTURED SUPPLY</span>:
            </p>
            <ul className="text-left inline-block space-y-3 text-secondary mb-10">
              <li>→ <span className="text-white">A clear, premium offer</span> (so they know what to buy)</li>
              <li>→ <span className="text-white">A conversion path</span> (so they know HOW to buy)</li>
              <li>→ <span className="text-white">Delivery operations</span> (so you can actually fulfill it)</li>
            </ul>
            <p className="text-xl font-medium text-white mb-8">
              That&apos;s what <AntigravityLogo /> builds.
            </p>

            <div className="flex justify-center">
              <a
                href="https://cal.com/at-info/20min"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full bg-white text-black font-semibold hover:bg-gray-100 transition-all"
              >
                Get Your Custom Blueprint
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

// Comparison Section
const ComparisonSection = () => {
  return (
    <section className="py-24 bg-surface relative overflow-hidden">
      <div className="container mx-auto px-6">
        <Reveal>
          <div className="text-center mb-16">
            <h2 className="text-2xl md:text-5xl font-bold mb-4">THE PROBLEM ISN&apos;T YOUR DRIVING.<br/>IT&apos;S YOUR VEHICLE.</h2>
            <p className="text-xl text-secondary max-w-xl mx-auto">
              You&apos;re trying to win a Formula 1 race on a bicycle.
            </p>
          </div>
        </Reveal>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* Problem Card */}
          <Reveal delay={0.1}>
            <motion.div 
              whileHover={{ scale: 1.02 }}
              className="p-6 md:p-8 rounded-3xl bg-background/50 border border-white/5 h-full relative overflow-hidden group transition-all duration-300 hover:bg-background/80 hover:border-white/10 hover:shadow-red-500/5"
            >
              <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
                <TrendingUp className="w-24 h-24 rotate-180" />
              </div>
              <div className="flex items-center gap-3 mb-6 text-red-400">
                <X className="w-6 h-6" />
                <span className="font-mono text-sm tracking-wider uppercase">THE BICYCLE (What you&apos;re doing now)</span>
              </div>
              <ul className="space-y-6 text-secondary">
                <li>
                  <strong className="text-red-200 block mb-1">Income:</strong>
                  Volatile AdSense & unpredictable sponsors
                </li>
                <li>
                  <strong className="text-red-200 block mb-1">Per Customer:</strong>
                  $0.05 per viewer (if lucky)
                </li>
                <li>
                  <strong className="text-red-200 block mb-1">Strategy:</strong>
                  &quot;Hope this goes viral&quot;
                </li>
                <li>
                  <strong className="text-red-200 block mb-1">Daily Reality:</strong>
                  Burnout, anxiety, and capped potential
                </li>
                <li>
                  <strong className="text-red-200 block mb-1">Revenue Ceiling:</strong>
                  $2K-$5K/month (on a good month)
                </li>
              </ul>
            </motion.div>
          </Reveal>

          {/* Solution Card */}
          <Reveal delay={0.2}>
            <motion.div 
              whileHover={{ scale: 1.02 }}
              className="p-6 md:p-8 rounded-3xl bg-gradient-to-br from-blue-900/20 to-purple-900/20 border border-blue-500/20 h-full relative overflow-hidden group transition-all duration-300 hover:border-blue-500/40 hover:shadow-blue-500/10"
            >
              <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity text-blue-500">
                <TrendingUp className="w-24 h-24" />
              </div>
              <div className="flex items-center gap-3 mb-6 text-blue-400">
                <CheckCircle2 className="w-6 h-6" />
                <span className="font-mono text-sm tracking-wider uppercase">THE F1 CAR (What we build)</span>
              </div>
              <ul className="space-y-6 text-blue-100/80">
                <li>
                  <strong className="text-white block mb-1">Income:</strong>
                  Owned high-ticket offer controlled by you
                </li>
                <li>
                  <strong className="text-white block mb-1">Per Customer:</strong>
                  $3,000+ per client
                </li>
                <li>
                  <strong className="text-white block mb-1">Strategy:</strong>
                  &quot;Funnel them to the application&quot;
                </li>
                <li>
                  <strong className="text-white block mb-1">Daily Reality:</strong>
                  Freedom, authority, and uncapped scale
                </li>
                <li>
                  <strong className="text-white block mb-1">Revenue Ceiling:</strong>
                  $20K-$50K/month (predictably)
                </li>
              </ul>
            </motion.div>
          </Reveal>
        </div>

        <Reveal delay={0.3}>
          <div className="max-w-xl mx-auto mt-16 text-center">
            <p className="text-xl text-white/90 leading-relaxed mb-6">
              Same creator.<br/>
              Same audience.<br/>
              Same expertise.
            </p>
            <p className="text-2xl font-bold text-white mb-8">
              Different vehicle.
            </p>
            <p className="text-xl text-purple-400 font-medium italic">
              Which one are you driving?
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

// Antigravity Engine Section
// Antigravity Animation Component
const AntigravityAnimation = () => {
  const [phase, setPhase] = useState(1);
  const [revenue, setRevenue] = useState(0);

  useEffect(() => {
    let timeout: NodeJS.Timeout;
    
    const runSequence = () => {
      setPhase(1);
      setRevenue(0);
      
      // Phase 1: 0-3s
      timeout = setTimeout(() => {
        setPhase(2);
        // Phase 2: 3-4s
        timeout = setTimeout(() => {
          setPhase(3);
          // Phase 3: 4-7s
          timeout = setTimeout(() => {
            setPhase(4);
            // Phase 4: 7-15s (hold for 5s after 10s mark)
            timeout = setTimeout(runSequence, 8000);
          }, 3000);
        }, 1000);
      }, 3000);
    };

    runSequence();
    return () => clearTimeout(timeout);
  }, []);

  // Revenue counter logic
  useEffect(() => {
    if (phase === 1) {
      const interval = setInterval(() => {
        setRevenue(r => (r < 141 ? r + 47 : r));
      }, 800);
      return () => clearInterval(interval);
    } else if (phase === 3) {
      const start = 3000;
      const end = 20000;
      const duration = 2500;
      const startTime = Date.now();
      const interval = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        setRevenue(Math.floor(start + (end - start) * progress));
        if (progress === 1) clearInterval(interval);
      }, 50);
      return () => clearInterval(interval);
    } else if (phase === 4) {
      setRevenue(20000);
    }
  }, [phase]);

  return (
    <div className="relative w-full min-h-[400px] md:min-h-[500px] flex flex-col items-center justify-center py-8 md:py-12">
      <AnimatePresence mode="wait">
        {/* PHASE 1: THE BROKEN MODEL */}
        {phase === 1 && (
          <motion.div
            key="phase1"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="relative flex flex-col items-center scale-90 md:scale-100"
          >
            <div className="relative w-full max-w-[200px] md:max-w-[240px] h-64 md:h-80 flex items-center justify-center">
              {/* Funnel Shape */}
              <svg width="100%" height="100%" viewBox="0 0 240 280" fill="none" className="text-white/20">
                <path d="M10 10 L230 10 L140 270 L100 270 Z" stroke="currentColor" strokeWidth="2" />
                <line x1="30" y1="60" x2="210" y2="60" stroke="currentColor" strokeWidth="1" strokeDasharray="4 4" />
                <line x1="50" y1="120" x2="190" y2="120" stroke="currentColor" strokeWidth="1" strokeDasharray="4 4" />
                <line x1="70" y1="180" x2="170" y2="180" stroke="currentColor" strokeWidth="1" strokeDasharray="4 4" />
              </svg>

              {/* Labels inside funnel */}
              <div className="absolute top-8 text-[8px] md:text-[10px] font-mono text-white/40">$47 Course</div>
              <div className="absolute top-24 text-[8px] md:text-[10px] font-mono text-white/40">$27 Ebook</div>
              <div className="absolute top-40 text-[8px] md:text-[10px] font-mono text-white/40">$9 Template</div>

              {/* Raining Dollars */}
              {[...Array(12)].map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ y: -100, x: (Math.random() - 0.5) * 150, opacity: 0 }}
                  animate={{ 
                    y: 350, 
                    x: (Math.random() - 0.5) * 200, // Most scatter
                    opacity: [0, 1, 1, 0] 
                  }}
                  transition={{ 
                    duration: 2, 
                    repeat: Infinity, 
                    delay: i * 0.2,
                    ease: "linear"
                  }}
                  className="absolute top-0 text-red-400 font-bold"
                >
                  $
                </motion.div>
              ))}
            </div>

            {/* Side Labels */}
            <div className="hidden md:block absolute -right-32 top-1/4 space-y-4">
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.5 }} className="text-red-400/60 font-mono text-xs border border-red-400/20 px-2 py-1 rounded">HIGH VOLUME</motion.div>
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 1.0 }} className="text-red-400/60 font-mono text-xs border border-red-400/20 px-2 py-1 rounded">LOW MARGIN</motion.div>
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 1.5 }} className="text-red-400/60 font-mono text-xs border border-red-400/20 px-2 py-1 rounded">HIGH CHURN</motion.div>
            </div>

            {/* Mobile Side Labels */}
            <div className="md:hidden flex gap-2 mt-4">
              <div className="text-red-400/60 font-mono text-[8px] border border-red-400/20 px-1 py-0.5 rounded uppercase">High Vol</div>
              <div className="text-red-400/60 font-mono text-[8px] border border-red-400/20 px-1 py-0.5 rounded uppercase">Low Margin</div>
              <div className="text-red-400/60 font-mono text-[8px] border border-red-400/20 px-1 py-0.5 rounded uppercase">High Churn</div>
            </div>

            <div className="mt-8 text-center">
              <div className="text-3xl font-bold text-white/40 font-mono mb-2">
                ${revenue.toLocaleString()}
              </div>
              <div className="text-sm font-bold tracking-widest text-white/20 uppercase">THE GRAVITY FUNNEL</div>
              <div className="text-xs text-white/10 mt-1 italic">Revenue: $2K-$5K/month</div>
            </div>
          </motion.div>
        )}

        {/* PHASE 2: THE BREAK */}
        {phase === 2 && (
          <motion.div
            key="phase2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="relative flex flex-col items-center scale-90 md:scale-100"
          >
            <motion.div
              animate={{ x: [-2, 2, -2, 2, 0], rotate: [-0.5, 0.5, -0.5, 0.5, 0] }}
              transition={{ duration: 0.1, repeat: Infinity }}
              className="relative"
            >
              <svg width="200" height="240" viewBox="0 0 240 280" fill="none" className="text-white/40 md:w-[240px] md:h-[280px]">
                <path d="M10 10 L230 10 L140 270 L100 270 Z" stroke="currentColor" strokeWidth="2" />
                {/* Crack */}
                <motion.path 
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  d="M120 10 L110 60 L130 110 L115 170 L125 270" 
                  stroke="#A78BFA" 
                  strokeWidth="3" 
                  className="drop-shadow-[0_0_8px_rgba(167,139,250,0.8)]"
                />
              </svg>
            </motion.div>
            
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1.2, opacity: 1 }}
              className="absolute top-1/2 -translate-y-1/2 text-2xl font-bold text-purple-400 tracking-tighter text-center glow-text"
            >
              WHAT IF YOU<br/>FLIPPED IT?
            </motion.div>

            {/* Shatter Particles (Simulated) */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: [0, 1, 0] }}
              transition={{ delay: 0.8, duration: 0.2 }}
              className="absolute inset-0 flex items-center justify-center"
            >
              {[...Array(20)].map((_, i) => (
                <motion.div
                  key={i}
                  animate={{ 
                    x: (Math.random() - 0.5) * 400, 
                    y: (Math.random() - 0.5) * 400,
                    rotate: Math.random() * 360,
                    scale: 0
                  }}
                  transition={{ duration: 0.5, ease: "easeOut" }}
                  className="absolute w-2 h-2 bg-white/20 rotate-45"
                />
              ))}
            </motion.div>
          </motion.div>
        )}

        {/* PHASE 3 & 4: THE REBUILD & REVEAL */}
        {(phase === 3 || phase === 4) && (
          <motion.div
            key="phase3"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="relative flex flex-col items-center scale-90 md:scale-100"
          >
            <div className="relative w-full max-w-[260px] md:max-w-[300px] h-80 md:h-96 flex items-center justify-center">
              {/* Inverted Funnel */}
              <svg width="100%" height="100%" viewBox="0 0 300 320" fill="none">
                <defs>
                  <linearGradient id="funnelGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#6B21A8" stopOpacity="0.8" />
                    <stop offset="100%" stopColor="#A78BFA" stopOpacity="0.2" />
                  </linearGradient>
                </defs>
                <motion.path 
                  initial={{ pathLength: 0, opacity: 0 }}
                  animate={{ pathLength: 1, opacity: 1 }}
                  transition={{ duration: 1.5 }}
                  d="M130 10 L170 10 L280 310 L20 310 Z" 
                  fill="url(#funnelGrad)"
                  stroke="#EAB308" 
                  strokeWidth="2" 
                  className="drop-shadow-[0_0_15px_rgba(167,139,250,0.3)]"
                />
                
                {/* Gold Accent Lines */}
                <motion.line x1="46" y1="240" x2="254" y2="240" stroke="#EAB308" strokeWidth="1" strokeOpacity="0.5" initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 1 }} />
                <motion.line x1="68" y1="180" x2="232" y2="180" stroke="#EAB308" strokeWidth="1" strokeOpacity="0.5" initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 1.2 }} />
                <motion.line x1="90" y1="120" x2="210" y2="120" stroke="#EAB308" strokeWidth="1" strokeOpacity="0.5" initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 1.4 }} />
              </svg>

              {/* Free Value & Dashed Line */}
              <div className="absolute -top-12 flex flex-col items-center">
                <div className="text-[10px] md:text-[12px] font-medium text-white/80 mb-1">Free Value</div>
                <div className="w-[1px] h-10 border-l border-dashed border-yellow-500/50"></div>
              </div>

              {/* Labels inside funnel */}
              <div className="absolute top-12 text-[10px] md:text-[12px] font-bold text-white drop-shadow-md">$3K-$5K Per Client</div>
              <div className="absolute top-32 text-[9px] md:text-[11px] font-medium text-white/80">$997 Group</div>
              <div className="absolute top-48 text-[8px] md:text-[10px] font-medium text-white/60">$47 Toolkit</div>
              <div className="absolute top-64 flex flex-col items-center">
                <div className="text-[8px] md:text-[10px] font-medium text-white/40">Free Content</div>
                <div className="text-[6px] md:text-[8px] font-medium text-white/30 mt-0.5">Nurturing</div>
              </div>

              {/* Floating Up Dollars */}
              {[...Array(15)].map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ y: 350, x: (Math.random() - 0.5) * 200, opacity: 0 }}
                  animate={{ 
                    y: -50, 
                    x: (Math.random() - 0.5) * 30, // All captured
                    opacity: [0, 1, 1, 0] 
                  }}
                  transition={{ 
                    duration: 2.5, 
                    repeat: Infinity, 
                    delay: i * 0.15,
                    ease: "easeOut"
                  }}
                  className="absolute bottom-0 text-yellow-400 font-bold text-xl"
                >
                  $
                </motion.div>
              ))}

              {/* Phase 4 Labels around funnel */}
              {phase === 4 && (
                <>
                  <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="absolute -top-10 left-1/2 -translate-x-1/2 text-[8px] md:text-[10px] font-mono text-purple-300 border border-purple-500/30 px-1.5 py-0.5 rounded bg-purple-500/10">01 DIAGNOSE</motion.div>
                  <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="absolute top-1/2 -right-16 md:-right-24 -translate-y-1/2 text-[8px] md:text-[10px] font-mono text-purple-300 border border-purple-500/30 px-1.5 py-0.5 rounded bg-purple-500/10">02 ENGINEER</motion.div>
                  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="absolute -bottom-10 left-1/2 -translate-x-1/2 text-[8px] md:text-[10px] font-mono text-purple-300 border border-purple-500/30 px-1.5 py-0.5 rounded bg-purple-500/10">03 BUILD</motion.div>
                  <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="absolute top-1/2 -left-16 md:-left-24 -translate-y-1/2 text-[8px] md:text-[10px] font-mono text-purple-300 border border-purple-500/30 px-1.5 py-0.5 rounded bg-purple-500/10">04 SCALE</motion.div>
                </>
              )}
            </div>

            {/* Side Labels */}
            <div className="hidden md:block absolute -right-32 top-1/4 space-y-4">
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.5 }} className="text-yellow-400 font-mono text-xs border border-yellow-400/20 px-2 py-1 rounded bg-yellow-400/5">LOW VOLUME</motion.div>
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 1.0 }} className="text-yellow-400 font-mono text-xs border border-yellow-400/20 px-2 py-1 rounded bg-yellow-400/5">HIGH MARGIN</motion.div>
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 1.5 }} className="text-yellow-400 font-mono text-xs border border-yellow-400/20 px-2 py-1 rounded bg-yellow-400/5">HIGH RETENTION</motion.div>
            </div>

            {/* Mobile Side Labels */}
            <div className="md:hidden flex gap-2 mt-4">
              <div className="text-yellow-400 font-mono text-[8px] border border-yellow-400/20 px-1 py-0.5 rounded uppercase">Low Vol</div>
              <div className="text-yellow-400 font-mono text-[8px] border border-yellow-400/20 px-1 py-0.5 rounded uppercase">High Margin</div>
              <div className="text-yellow-400 font-mono text-[8px] border border-yellow-400/20 px-1 py-0.5 rounded uppercase">High Ret</div>
            </div>

            <div className="mt-8 text-center">
              <motion.div 
                animate={phase === 4 ? { scale: [1, 1.05, 1] } : {}}
                transition={{ duration: 2, repeat: Infinity }}
                className="text-4xl font-black text-white font-mono mb-2 drop-shadow-[0_0_15px_rgba(255,255,255,0.5)]"
              >
                ${revenue.toLocaleString()}{phase === 4 ? "+" : ""}
              </motion.div>
              <div className="text-lg font-bold tracking-widest text-white uppercase flex items-center justify-center gap-1">
                THE <span className="text-purple-400 inline-block rotate-180">A</span>NTIGRAVITY ENGINE™
              </div>
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1 }}
                className="text-sm text-purple-300/80 mt-1 font-medium"
              >
                Flip the funnel. 10x the revenue. Same audience.
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const AntigravityEngineSection = () => {
  const steps = [
    {
      num: "01",
      title: "DIAGNOSE THE LEAK",
      desc: "We analyze your current traffic, audience demographics, and content strategy to find exactly where your revenue is leaking."
    },
    {
      num: "02",
      title: "ENGINEER THE OFFER",
      desc: "We craft a $3K-$5K high-ticket offer specifically designed for your top 1% of followers. No cheap courses. No low-margin memberships."
    },
    {
      num: "03",
      title: "BUILD THE ENGINE",
      desc: "We install the Antigravity Funnel: VSLs, automated email sequences, and application flows that convert attention into booked calls."
    },
    {
      num: "04",
      title: "SCALE WITHOUT CHAOS",
      desc: "We implement delivery operations, client success protocols, and retention loops so you can handle 50+ clients without burning out."
    }
  ];

  return (
    <section id="system" className="py-24 bg-background relative overflow-hidden">
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-[120px] mix-blend-screen" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-[120px] mix-blend-screen" />

      <div className="container mx-auto px-6 relative z-10">
        <Reveal>
          <div className="text-center mb-12 md:mb-20">
            <h2 className="text-2xl md:text-6xl font-bold mb-4 flex items-center justify-center flex-wrap gap-x-4 gap-y-2">
              <span className="font-serif italic text-purple-400">THE</span>
              <AntigravityLogo />
            </h2>
            <p className="text-base md:text-xl text-secondary max-w-2xl mx-auto px-4">
              A 4-step architecture to turn your audience into a predictable high-ticket business.
            </p>
          </div>
        </Reveal>

        {/* Animation Element */}
        <Reveal delay={0.1}>
          <div className="max-w-4xl mx-auto mb-16 md:mb-20 p-4 md:p-8 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-sm relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-b from-purple-500/10 to-transparent opacity-50" />
            <div className="relative z-10">
              <h3 className="text-lg md:text-2xl font-bold text-white mb-6 text-center">Gravity vs. Antigravity</h3>
              <AntigravityAnimation />
            </div>
          </div>
        </Reveal>

        {/* 4-Card Grid */}
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
          {steps.map((s, i) => (
            <Reveal key={s.num} delay={i * 0.1}>
              <motion.div 
                whileHover={{ y: -5, scale: 1.02 }}
                className="glass-panel rounded-3xl p-8 border border-white/5 bg-white/5 h-full transition-all duration-300 hover:bg-white/10 hover:border-white/20 hover:shadow-xl"
              >
                <div className="flex items-start justify-between mb-5">
                  <div className="text-xs font-mono text-secondary">PHASE</div>
                  <div className="text-sm font-mono text-purple-400">{s.num}</div>
                </div>
                <h3 className="text-2xl font-bold mb-4 text-white">{s.title}</h3>
                <p className="text-secondary leading-relaxed text-lg">{s.desc}</p>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};

// Deliverables Section
const DeliverablesSection = () => {
  const bonuses = [
    { name: "IG STORY TEMPLATES", value: "$500" },
    { name: "AUTOMATED ACQUISITION", value: "$4,997" },
    { name: "OFFER MASTERY GUIDE", value: "$3,000" },
    { name: "MENTALITY MASTERMIND", value: "$297" },
    { name: "SALES MASTERY COURSE", value: "$6,000" },
    { name: "COACHING LITERACY", value: "$999" },
    { name: "LEADERSHIP LITERACY", value: "$999" },
  ];

  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-6">
        <Reveal>
          <div className="mb-12 text-center md:text-left">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 uppercase">WHAT WE INSTALL INSIDE YOUR BUSINESS</h2>
            <p className="text-secondary">
              This isn&apos;t a course. This isn&apos;t a template pack.<br />
              This is a complete revenue machine — engineered, built, and installed for you.
            </p>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {/* Card 1 */}
          <Reveal delay={0.05}>
            <motion.div 
              whileHover={{ y: -5, scale: 1.02 }}
              className="glass-panel p-8 rounded-3xl h-full border border-white/5 transition-all duration-300 hover:bg-white/10 hover:border-white/20 hover:shadow-purple-500/10"
            >
              <TrendingUp className="w-8 h-8 text-blue-400 mb-4" />
              <h3 className="text-xl font-bold mb-2">The Grand Slam Offer</h3>
              <p className="text-secondary text-sm leading-relaxed">
                We engineer an offer so good they feel stupid saying no. (Includes ICP Clarity & Value Ladder construction).
              </p>
            </motion.div>
          </Reveal>
          {/* Card 2 */}
          <Reveal delay={0.1}>
            <motion.div 
              whileHover={{ y: -5, scale: 1.02 }}
              className="glass-panel p-8 rounded-3xl h-full border border-white/5 transition-all duration-300 hover:bg-white/10 hover:border-white/20 hover:shadow-purple-500/10"
            >
              <Lock className="w-8 h-8 text-purple-400 mb-4" />
              <h3 className="text-xl font-bold mb-2">The Trust Engine</h3>
              <p className="text-secondary text-sm leading-relaxed">
                A content system that moves leads from &quot;Problem Aware&quot; to &quot;Ready to Buy&quot; before you ever speak to them.
              </p>
            </motion.div>
          </Reveal>
          {/* Card 3 */}
          <Reveal delay={0.15}>
            <motion.div 
              whileHover={{ y: -5, scale: 1.02 }}
              className="glass-panel p-8 rounded-3xl h-full border border-white/5 transition-all duration-300 hover:bg-white/10 hover:border-white/20 hover:shadow-purple-500/10"
            >
              <BarChart3 className="w-8 h-8 text-green-400 mb-4" />
              <h3 className="text-xl font-bold mb-2">Automated Acquisition</h3>
              <p className="text-secondary text-sm leading-relaxed">
                The exact VSL structure, Webinar scripts, and Outreach flows to fill your calendar with qualified buyers.
              </p>
            </motion.div>
          </Reveal>
          {/* Card 4 */}
          <Reveal delay={0.2}>
            <motion.div 
              whileHover={{ y: -5, scale: 1.02 }}
              className="glass-panel p-8 rounded-3xl h-full border border-white/5 transition-all duration-300 hover:bg-white/10 hover:border-white/20 hover:shadow-purple-500/10"
            >
              <ShieldCheck className="w-8 h-8 text-yellow-400 mb-4" />
              <h3 className="text-xl font-bold mb-2">Objection Annihilation</h3>
              <p className="text-secondary text-sm leading-relaxed">
                Sales scripts that close the 7 Doors of resistance (Money, Time, Fear) before the pitch even happens.
              </p>
            </motion.div>
          </Reveal>
          {/* Card 5 */}
          <Reveal delay={0.25}>
            <motion.div 
              whileHover={{ y: -5, scale: 1.02 }}
              className="glass-panel p-8 rounded-3xl h-full border border-white/5 transition-all duration-300 hover:bg-white/10 hover:border-white/20 hover:shadow-purple-500/10"
            >
              <Users className="w-8 h-8 text-blue-300 mb-4" />
              <h3 className="text-xl font-bold mb-2">The Ascension Playbook</h3>
              <p className="text-secondary text-sm leading-relaxed">
                A delivery system built for retention, ensuring your clients stay, pay, and refer others to your ecosystem.
              </p>
            </motion.div>
          </Reveal>
          {/* Card 6 */}
          <Reveal delay={0.3}>
            <motion.div 
              whileHover={{ y: -5, scale: 1.02 }}
              className="glass-panel p-8 rounded-3xl h-full border border-white/5 transition-all duration-300 hover:bg-white/10 hover:border-white/20 hover:shadow-purple-500/10"
            >
              <Zap className="w-8 h-8 text-purple-300 mb-4" />
              <h3 className="text-xl font-bold mb-2">Team Architecture</h3>
              <p className="text-secondary text-sm leading-relaxed">
                The exact SOPs and org chart to go from &quot;Solo Creator&quot; to &quot;Business Owner&quot; with a lean, high-profit team.
              </p>
            </motion.div>
          </Reveal>
        </div>

        {/* Bonuses */}
        <Reveal delay={0.35}>
             <motion.div 
                whileHover={{ scale: 1.005 }}
                className="relative overflow-hidden rounded-3xl p-[1px] bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-blue-500/20 shadow-lg hover:shadow-purple-500/20 transition-shadow duration-300 mb-12"
             >
                <div className="relative bg-background/80 backdrop-blur-xl rounded-[23px] p-8 md:p-12 text-center overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-50"></div>
                    <div className="relative z-10">
                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-mono text-blue-200 mb-6">
                            <span className="relative flex h-2 w-2">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                            </span>
                            LIMITED AVAILABILITY
                        </div>
                        <h3 className="text-3xl md:text-4xl font-bold text-white mb-2">
                            Exclusive Bonuses
                        </h3>
                        <p className="text-lg text-secondary/80 max-w-2xl mx-auto italic mb-10">
                           &quot;At The Cost of <span className="text-red-500 font-bold not-italic">NOTHING</span> if you show up for the call&quot;
                        </p>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto text-left">
                            {bonuses.map((b, i) => (
                                <div key={i} className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/5">
                                    <span className="font-medium text-white">{b.name}</span>
                                    <span className="text-sm font-mono text-blue-300 bg-blue-500/10 px-2 py-1 rounded">
                                        worth {b.value}
                                    </span>
                                </div>
                            ))}
                        </div>
                        <p className="mt-6 text-sm text-secondary/70 italic text-center">
                            We don&apos;t stack *fake* bonuses to inflate perceived value.
                        </p>
                    </div>
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-blue-500/10 rounded-full blur-[80px] pointer-events-none" />
                </div>
             </motion.div>
        </Reveal>

        {/* New CTA */}
        <Reveal delay={0.4}>
            <div className="flex justify-center">
                <a 
                href="https://cal.com/at-info/20min" 
                target="_blank"
                rel="noreferrer"
                className="group relative px-10 py-5 bg-white text-black text-lg font-bold rounded-full hover:scale-105 transition-all shadow-[0_0_40px_-10px_rgba(255,255,255,0.3)] hover:shadow-[0_0_60px_-15px_rgba(255,255,255,0.5)] flex items-center gap-3"
              >
                Get Your Personalized Antigravity Blueprint (Free)
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>
            </div>
        </Reveal>
      </div>
    </section>
  );
};

// FAQ Accordion Component
const GlassyFAQAccordion = ({ items }: { items: { question: string; answer: React.ReactNode }[] }) => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div className="divide-y divide-white/10">
      {items.map((item, idx) => {
        const isOpen = openIndex === idx;
        return (
          <div key={item.question} className="py-2">
            <motion.button
              type="button"
              onClick={() => setOpenIndex(isOpen ? null : idx)}
              className="w-full text-left flex items-start justify-between gap-4 rounded-2xl px-4 py-4 hover:bg-white/5 transition-colors"
              initial={false}
              whileHover={{ scale: 1.005 }}
              whileTap={{ scale: 0.995 }}
            >
              <div className="min-w-0">
                <div className="text-white font-semibold leading-snug">
                  {item.question}
                </div>
              </div>
              <motion.div
                className="shrink-0 mt-0.5 w-8 h-8 rounded-xl border border-white/10 bg-white/5 flex items-center justify-center"
                animate={{ rotate: isOpen ? 45 : 0 }}
                transition={{ type: "spring", stiffness: 260, damping: 18 }}
              >
                <span className="text-white/80 text-xl leading-none select-none">+</span>
              </motion.div>
            </motion.button>
            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  key="content"
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.22, ease: "easeOut" }}
                  className="overflow-hidden"
                >
                  <motion.div
                    initial={{ y: -6, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: -6, opacity: 0 }}
                    transition={{ duration: 0.18, ease: "easeOut" }}
                    className="px-4 pb-4"
                  >
                    <div className="rounded-2xl border border-white/10 bg-background/30 p-4">
                      <p className="text-secondary leading-relaxed whitespace-pre-line">
                        {item.answer}
                      </p>
                    </div>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
};

// FAQ Section
const FAQSection = () => {
  const faqs = [
    {
      question: "Q: What is the AntiGravity System Audit?",
      answer: <>It is a comprehensive operational audit that maps exactly how to install <AntigravityLogo /> into your existing workflow. Think of it as an X-ray for your business. You will receive a technical blueprint for high-ticket offer architecture, automated data routing, and setter sales protocols—designed to move your brand from algorithmic dependency to a sovereign, scalable asset.</>
    },
    {
      question: "Is it really free?",
      answer: "Yes. The AntiGravity System Audit is completely free. No catch. If there's a fit to work together, I'll explain what that looks like. If not, you still walk away with a clear plan."
    },
    {
      question: "Who is this for?",
      answer: `This is for creators who have consistent content and real audience trust, want a clear monetization path that doesn't feel salesy, prefer systems over "post more" advice, and want to build (or improve) an offer like a cohort, program, or product ladder.`
    },
    {
      question: "Who is this not for?",
      answer: `Not for you if you want quick hacks or "go viral" tactics, you're looking for someone to do everything while you stay hands-off, you don't want to sell anything at all (ever), or you're expecting guaranteed revenue outcomes (no one ethical can promise that).`
    },
    {
      question: "Do I need a big audience?",
      answer: "No. You need signal, not size. If people are saving, replying, DM'ing, or asking questions, you have monetizable demand—even with a smaller audience."
    },
    {
      question: "What if I don't have a product yet?",
      answer: "That's completely fine. A big part of the call is helping you turn what you already teach into a clear offer, a simple product ladder, and an easy \"next step\" for your audience to buy. You don't need a finished product to book."
    },
    {
      question: "What if I already have a course that isn't selling?",
      answer: `That's one of the most common cases. Usually the problem isn't "the course is bad"—it's unclear positioning (wrong promise for the right people), weak bridge from content → offer, no conversion system (DM/email/waitlist), or no reason to buy now. We'll diagnose which one it is and map the fix.`
    },
    {
      question: "How long is the diagnostic call?",
      answer: "15–20 minutes. Short, focused, and structured."
    },
    {
      question: "What do I need to bring?",
      answer: "Just these (no spreadsheets required): your IG/YouTube/TikTok profile link, your current offer (if you have one), a quick summary of what you sell (or want to sell), and your biggest bottleneck right now (one sentence). Optional but helpful: screenshots of common audience questions / DMs."
    },
    {
      question: "What will I leave with?",
      answer: "By the end, you'll have: the real bottleneck identified (clarity, offer, conversion, launch, or delivery), a recommended offer structure (even if you have nothing yet), a simple content → lead → sale path, and 2–3 next steps you can implement immediately. No fluff. Just a clear plan."
    },
    {
      question: "Will I need paid ads?",
      answer: "Not necessarily. We typically start with organic systems first (content + DM + lead capture). Ads become useful when your message converts organically, you want to scale what already works, or you want more consistent lead flow. If ads make sense for you, I'll tell you. If not, I'll tell you that too."
    },
    {
      question: "How soon can I see revenue?",
      answer: "Depends on what you already have. If you have audience trust + clear demand, revenue can come quickly once the offer + conversion path is installed. If you're starting from zero structure, the first step is building the system correctly so results compound. The call will give you a realistic timeline based on your situation."
    },
    {
      question: "What if I hate selling?",
      answer: "Perfect. This is built for creators who hate selling. The goal is not to turn you into a salesperson—it's to build a system where your content does the trust-building, your offer feels like the natural next step, and your DM and funnel process stays simple and respectful."
    }
  ];

  return (
    <section className="py-24 bg-background relative overflow-hidden" id="faq">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-blue-500/10 rounded-full blur-[90px]" />
        <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-purple-500/10 rounded-full blur-[90px]" />
        <div className="absolute inset-0 bg-grid-white/[0.03]" />
      </div>

      <div className="container mx-auto px-6 max-w-4xl relative z-10">
        <div className="text-center mb-12">
          <div className="text-xs font-mono tracking-widest text-secondary uppercase mb-3">
            FAQ
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-3">Common Questions</h2>
          <p className="text-secondary">Everything you need to know before booking</p>
        </div>

        <motion.div 
          whileHover={{ scale: 1.005 }}
          className="glass-panel rounded-3xl p-4 md:p-8 border border-white/10 bg-white/5 transition-all duration-300 hover:bg-white/10 hover:border-white/20 hover:shadow-2xl"
        >
          <GlassyFAQAccordion items={faqs} />
        </motion.div>
      </div>
    </section>
  );
};

// About Me / Founder Memo Section
const AboutMeSection = () => {
  return (
    <section className="py-24 bg-background relative overflow-hidden" id="about">
       <div className="container mx-auto px-6 relative z-10">
            <div className="max-w-4xl mx-auto">
              <div className="glass-panel p-6 md:p-12 rounded-3xl border border-white/10 bg-white/5 relative overflow-hidden">
                 <div className="relative z-10">
                    <h2 className="text-2xl md:text-3xl font-bold mb-8 font-serif tracking-tight">About The Founder</h2>
                    
                    <div className="space-y-6 text-secondary leading-relaxed text-base md:text-lg font-light">
                        <p>
                          As a child, I was quiet—not by choice, but by confusion. Words felt like landmines in my mouth. Every time I opened it, chaos followed. So I learned silence, even as the world around me grew louder with judgment.
                        </p>
                        <p>
                          They mocked my body. They ridiculed my broken speech. I became a target for cruelty I didn’t understand and couldn’t escape.
                        </p>
                        <p>
                          But I had a dream: to become a football player. I poured everything into that dream—every ounce of hope, every drop of defiance. Until the day the club kicked me out. Just like that, my dream evaporated. And with it, any sense of direction.
                        </p>
                        
                        <div className="pt-4">
                           <h3 className="text-white font-semibold text-xl mb-2">The Boy Who Scored 99% but Had No Answer</h3>
                           <p>
                             I entered high school hollow. No goals. No vision. Just one flickering light in the darkness: making my parents proud.
                             I studied relentlessly—not for myself, but for them. To see pride replace worry in their eyes. To give them something to celebrate.
                           </p>
                           <p className="mt-2">
                             I scored 99%. Everyone congratulated me. But inside, I felt nothing. What’s a perfect score when you don’t know what you’re scoring for?
                           </p>
                        </div>

                        <div className="pt-4">
                           <h3 className="text-white font-semibold text-xl mb-2">The Entrepreneur Who Kept Failing</h3>
                           <p>
                             At fourteen, I discovered entrepreneurship. A new dream, a new chance.
                             I created content on Instagram. YouTube. LinkedIn. I hustled in the shadows while my classmates slept.
                           </p>
                           <p className="mt-2">
                             Instagram? Failed. YouTube? Failed.
                           </p>
                           <p className="mt-2">
                             At sixteen, I pivoted to LinkedIn. Finally, traction. Numbers grew. Engagement rose. I thought I’d made it.
                             Then reality hit: no one wanted to buy my SMMA services.
                             Another dream. Another failure. Another return to the fog of confusion.
                           </p>
                        </div>

                        <div className="pt-4">
                           <h3 className="text-white font-semibold text-xl mb-2">The Turning Point</h3>
                           <p>
                             At sixteen, I turned to God. Not out of desperation—out of clarity. I stopped asking “Why me?” and started asking “What now?”
                           </p>
                           <p className="mt-2">
                             I realized something profound: I didn’t want success for myself. I wanted it for them.
                             My parents. My siblings. The people who believed in me when I couldn’t believe in myself. They deserved better. They deserved the life I was determined to build.
                           </p>
                        </div>

                         <div className="pt-4">
                           <h3 className="text-white font-semibold text-xl mb-2">The Transformation</h3>
                           <p>
                             I rebuilt myself, piece by piece.
                           </p>
                           <ul className="list-disc pl-5 space-y-1 mt-2 marker:text-blue-400">
                              <li>My body? I trained it. Sculpted it. Made it strong.</li>
                              <li>My speech? I worked on it daily. Learned to communicate. Learned to connect.</li>
                              <li>My skills? I dove into Info Growth Operations. I mastered content creation. I studied every detail, every strategy, every framework.</li>
                           </ul>
                           <p className="mt-2">This time, I didn’t quit.</p>
                        </div>
                        
                        <div className="pt-4">
                           <h3 className="text-white font-semibold text-xl mb-2">The Mission</h3>
                           <p>
                             I’m closer now than I’ve ever been. Not just to success—to purpose.
                             I don’t want ordinary success. I don’t want to just make money. I want to serve people. To uplift my community. To prove that the boy who couldn’t speak right, whose body was mocked, who failed at football and failed in business—that he could rise.
                           </p>
                           <p className="mt-2">Not despite his failures. Because of them.</p>
                        </div>

                        <p className="pt-6 font-medium text-white italic">
                           Doing it for the little boy I used to be, he still exists in me, quietly hoping, still dreaming. And this time, I won’t let him down.
                           <br />
                           I’ll make him proud.
                        </p>
                    </div>

                    <div className="mt-12 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-8 border-t border-white/10 pt-8">
                       <div>
                          <p className="font-serif italic text-2xl text-white mb-2">Peace.</p>
                       </div>
                       
                       <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center text-white font-bold text-lg border border-white/20">
                             AT
                          </div>
                          <div>
                             <div className="text-white font-semibold">Abdo Tamer</div>
                             <div className="text-sm text-secondary">CEO of ATIA</div>
                          </div>
                       </div>
                    </div>

                 </div>
              </div>
            </div>
       </div>
    </section>
  )
}

// CTA Section
const CTASection = () => {
  return (
    <section id="diagnostic" className="py-32 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-surface to-background" />
      <div className="container mx-auto px-6 relative z-10">
        <Reveal>
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl md:text-6xl font-bold mb-8 tracking-tight">
              READY?
            </h2>
            <p className="text-xl text-secondary mb-12 max-w-2xl mx-auto">
              20 minutes. Your custom Antigravity Blueprint. Free.
            </p>
            <div className="flex flex-col items-center gap-6">
              <a 
                href="https://cal.com/at-info/20min" 
                target="_blank"
                rel="noreferrer"
                className="group relative px-6 py-4 md:px-10 md:py-5 bg-purple-600 hover:bg-purple-700 text-white text-lg font-semibold rounded-full transition-all shadow-[0_0_40px_-10px_rgba(147,51,234,0.5)] hover:shadow-[0_0_60px_-15px_rgba(147,51,234,0.7)] flex flex-col items-center gap-1 text-center w-full max-w-lg"
              >
                <div className="flex items-center gap-2 text-sm md:text-lg">
                  Get Your Personalized Antigravity Blueprint <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </div>
                <div className="text-[9px] md:text-sm font-normal text-white/80">
                  Free 20-Min Revenue Audit (No Pitch, Just Your Custom Growth Map)
                </div>
              </a>
              <a 
                href="#faq"
                className="text-sm text-secondary font-mono hover:text-white transition-colors border border-white/10 px-4 py-2 rounded-full hover:bg-white/5"
              >
                Still have questions? Read the FAQ above ↑
              </a>
              <p className="text-sm text-secondary font-mono mt-4">
                <span className="inline-block w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse"/>
                We only accept 2 Diagnostic calls a week. Try Your Best NoW!
              </p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

// Footer
const Footer = () => {
  return (
    <footer className="py-12 border-t border-white/5 bg-background text-secondary text-sm">
      <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="font-bold text-white tracking-tighter">ATIA<span className="text-purple-500">.</span></div>
        <div>
          &copy; {new Date().getFullYear()} ATIA. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

// Main Index Layout
const Index = () => {
  useEffect(() => {
    document.title = "AT Info | Creator Monetization Diagnostic";
  }, []);

  return (
    <main className="relative bg-background min-h-screen text-white selection:bg-blue-500/30">
      <Navbar />
      <HeroSection />
      <FitSection />
      <SocialProofSection />
      <RealProblemSection />
      <ComparisonSection />
      <AntigravityEngineSection />
      <DeliverablesSection />
      <FAQSection />
      <AboutMeSection />
      <CTASection />
      <Footer />
    </main>
  );
};

export default Index;